package com.campionpumps.webservices.qrcode;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

public class ListItemClicked implements AdapterView.OnItemClickListener
{
    private BluetoothLE bluetoothObject = new BluetoothLE();

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        // TODO Auto-generated method stub
        bluetoothObject.bdDevice = bluetoothObject.arrayListBluetoothDevices.get(position);

        Log.i("Log", "The device : " + bluetoothObject.bdDevice.toString());

        bluetoothObject.connectToDevice(bluetoothObject.bdDevice);
    }
}
package com.campionpumps.webservices.qrcode; /**
 * Created by Kushal.Mishra on 22/02/2018.
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import services.AlarmNotifications;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //   FacebookSdk.setApplicationId("com.campionpumps.webservices.qrcode");
        setContentView(R.layout.activity_main);
/*
        Settings.sdkInitialize(this);

        LikeView likeView = (LikeView) findViewById(R.id.like_view);
        likeView.setObjectIdAndType(
                "https://www.facebook.com/FacebookDevelopers",
                LikeView.ObjectType.PAGE);*/

    }

    public void readQr(View view) {
        Intent intent = new Intent(MainActivity.this, QrRead.class);
        startActivity(intent);
    }

    public void generateQr(View view) {
        Intent intent = new Intent(MainActivity.this, QrGenerate.class);
        startActivity(intent);
    }

    public void bluetoothMenu(View view) {
        Intent intent = new Intent(MainActivity.this, BluetoothLE.class);
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        startService(new Intent(MainActivity.this, AlarmNotifications.class));
    }
}